--Zone: Dynamis - San d'Oria [D]
--Zone ID: 294
return {
    Names = {
    },
    Indices = {
    },
};