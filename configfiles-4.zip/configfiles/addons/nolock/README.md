# nolock
Ashita v4 addon that allows you to engage/disengage without animation lock, from effects such as spells being cast on you or mob tp moves.

This is seperate from similar plugins/addons like JaZero and Butterfeet in that it does not allow you to slide around during animations.
Credit to the original ASM patch is unknown to me.

# Known issues
There may be some slight disconnect to where your weapon is located compared to your hand when engaging/disengaging depending on race & weapon type.
It is merely cosmetic and wlil fix itself once the animations are complete.