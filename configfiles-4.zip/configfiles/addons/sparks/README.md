# Sparks

Enables buying sparks equipment easier. **Please note I do not enable looping, this just skips the menus for one purchase only.**


Find a sparks NPC and stand near them, within 5' / talking distance and issue the command
/sparks buy <item>

ie

/sparks buy negoroshiki


**Uses Packets**


2.0.0.3 updated to fix /buyall

/sparks buyall "item"

will buy till your inventory fills or you run out of sparks (does not currently put items away)
