addon.version = '0.1';
addon.name    = 'lsbcustommenufixjp';
addon.desc    = 'Enables JP client to operate custom menus.';
addon.author  = 'DB';

require('common');
local ffi = require('ffi');

ffi.cdef[[
    typedef struct packet_outgoing_tell_t {
        uint32_t Header;
        uint16_t Unknown1;
        char     TargetName[15];
        char     Message[];
    } packet_outgoing_tell_t;
]];

ashita.events.register('packet_out', 'packet_out_cb', function(e)

    if (e.id == 0x0B6 and not e.injected) then
        local telldata = ffi.cast('packet_outgoing_tell_t*', e.data_modified_raw);
        if
            ffi.string(telldata.TargetName, 12) == "_CUSTOM_MENU" and
            telldata.TargetName[12] == 0x00
        then
            local message = ffi.string(telldata.Message);
            -- Replace "結果" (Shift-JIS) by "Result".
            message = message:gsub("%):" .. string.char(0x8C, 0x8B, 0x89, 0xCA) .. "%(", "): Result (");
            -- Replace "キャンセル" (Shift-JIS) by "Canceled.".
            message = message:gsub("%(" .. string.char(0x83, 0x4C, 0x83, 0x83, 0x83, 0x93, 0x83, 0x5A, 0x83, 0x8B) .. "%)", "(Canceled.)");
            -- Assemble packets with replaced response messages.
            ffi.copy(telldata.Message, message);
            local inject_packet = ffi.string(telldata, ffi.sizeof('packet_outgoing_tell_t') + #message):totable();
            -- Inject new repsponse packet. 
            AshitaCore:GetPacketManager():AddOutgoingPacket(0xB6, inject_packet);
            -- Block the original response message packet.
            e.blocked = true;
            return true;
        end
    end
end)
