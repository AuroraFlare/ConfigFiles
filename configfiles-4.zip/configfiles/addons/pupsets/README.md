Ashita v4 blusets by atom0s modified to support PUP. Ashita v3 pupsets by DivByZero used for additional reference.
- Only tested on retail
 
# PupSets
### Manage pup attachments easily with slash commands

Attachment files shall contain one entry per line starting with head then body then attachments. Head and body entries are required. Attachment entries may be optionally be included up to 12 attachments.

It is recommended to configure the puppet ingame and use '/pupsets save \<file\>' to create the attachment file instead of manually creating files to avoid issues with elemental capacity.

#### Example attachment file:

    Soulsoother Head
    Valoredge Frame
    Optic Fiber
    Optic Fiber II
    Attuner
    Auto-Repair Kit IV
    Magniplug
    Magniplug II
    Turbo Charger
    Turbo Charger II
    Flame Holder
    Inhibitor II
    Mana Jammer
    Mana Jammer II
