# Corsair Rolltracker
### "Beautifies" Roll Text look 

### installation
Place RollTracker folder with the lua file inside into the addons directory of Ashita, load in game via:

/addon load rolltracker

### notes
None

### settings
*EnableLuckyUnluckyDisplay (Default: False)* \
Adds [ Lucky / Unlucky ] additional text to the roll message \
example: John Doe → Chaos Roll [4 / 6] ⑤ (+10.9% Attack)

### commands
None

### images
![Image of Rolltracker](Rolltracker_Screenshot.png)
