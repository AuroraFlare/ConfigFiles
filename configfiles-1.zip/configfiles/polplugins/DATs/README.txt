Place any DAT-Overlays that you want to use with XI-pivot into this directory.
The layout should be a base directory named after the mod and the ROM-directories below it.

For example - for XI-View:

XI-View\
  +-- ROM\
  +-- ROM2\
  ..
